package exceptionHierarchy;

/**
 * 
 * @author Keith Tanner
 * Title: LevelThreeException.java
 * 
 */
public class LevelThreeException extends LevelTwoException {
}