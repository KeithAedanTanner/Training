package exceptionHierarchy;

/**
 * 
 * @author Keith Tanner
 * Title: LevelTwoException.java
 * 
 */
public class LevelTwoException extends LevelOneException {
}