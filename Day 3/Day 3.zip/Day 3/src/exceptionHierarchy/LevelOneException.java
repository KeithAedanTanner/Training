package exceptionHierarchy;

/**
 * 
 * @author Keith Tanner
 * Title: LevelOneException.java
 * 
 */
public class LevelOneException extends Exception {
}