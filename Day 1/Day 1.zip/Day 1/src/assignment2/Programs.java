package assignment2;

/**
 * 
 * @author Keith Tanner
 * Title: Programs.java
 * Description: Displays the following series:
 *     *
 *    * *
 *   * * *
 *  * * * *
 * * * * * *
 * 
 */
public class Programs {
	public static void main(String[] args) {
		System.out.println("    *");
		System.out.println("   * *");
		System.out.println("  * * *");
		System.out.println(" * * * *");
		System.out.println("* * * * *");
	}
}